// FICHIER SUPPRIMÉ - Non utilisé dans la version statique finale
// Configuration de déploiement qui était utilisée pour basculer entre modes
// La version statique utilise maintenant directement les composants appropriés

export const DEPLOYMENT_CONFIG = {
  MODE: 'static',
  BACKEND_ENABLED: false,
  // Configuration conservée pour compatibilité mais non utilisée
};