// FICHIER SUPPRIMÉ - Non utilisé dans la version statique
// Ce fichier était utilisé pour le tableau de bord administrateur
// avec base de données Supabase qui n'est plus nécessaire.

export function DashboardPage() {
  return null;
}