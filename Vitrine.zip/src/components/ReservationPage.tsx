// FICHIER SUPPRIMÉ - Non utilisé dans la version statique
// Ce fichier était utilisé pour les réservations avec base de données
// Supabase. Remplacé par ReservationPageStatic.tsx

export function ReservationPage() {
  return null;
}