// FICHIER SUPPRIMÉ - Configuration Supabase non utilisée
// Ce fichier contenait les identifiants de connexion Supabase
// Non nécessaire pour la version statique

export const projectId = 'static-version';
export const publicAnonKey = 'not-used-in-static-version';