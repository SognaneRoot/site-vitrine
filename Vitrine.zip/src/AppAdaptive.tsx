// FICHIER SUPPRIMÉ - Non utilisé dans la version statique finale
// Ce fichier était une version adaptative qui basculait entre backend et statique
// App.tsx utilise maintenant directement la version statique

export default function AppAdaptive() {
  return null;
}