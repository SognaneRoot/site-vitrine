// FICHIER SUPPRIMÉ - Backend Supabase non utilisé
// Ce fichier contenait l'API backend complète pour la gestion des événements
// et réservations. Remplacé par des solutions statiques.

export default function handler() {
  return new Response('Backend désactivé - Version statique', { status: 410 });
}